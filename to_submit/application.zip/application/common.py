#file with functions common to all pages

from security import update_time

def update(ip_addr):
	update_time(ip_addr)